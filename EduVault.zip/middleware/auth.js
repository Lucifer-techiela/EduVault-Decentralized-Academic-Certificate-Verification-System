const jwt = require('jsonwebtoken');

function requireRole(role, secret) {
  return (req, res, next) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Unauthorized: Missing JWT token' });
    }
    try {
      const decoded = jwt.verify(authHeader.split(' ')[1], secret);
      if (decoded.role !== role) {
        return res.status(403).json({ error: '403 Forbidden: Insufficient role privileges' });
      }
      req.user = decoded;
      next();
    } catch (err) {
      return res.status(401).json({ error: 'Unauthorized: Invalid or expired token' });
    }
  };
}

module.exports = { requireRole };
