const mongoose = require('mongoose');

const certificateSchema = new mongoose.Schema({
  credentialId: { type: String, required: true, unique: true, index: true },
  studentName: { type: String, required: true, trim: true },
  rollNo: { type: String, required: true, trim: true },
  course: { type: String, required: true, trim: true },
  year: { type: String, required: true, trim: true },
  hash: { type: String, required: true },
  issuedBy: { type: String, default: 'Lloyd Institute of Engineering & Technology' },
  issuedAt: { type: Date, default: Date.now }
});

module.exports = mongoose.models.Certificate || mongoose.model('Certificate', certificateSchema);
